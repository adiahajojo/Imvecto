"use client";

import Link from "next/link";
import { useSession, signOut } from "next-auth/react";
import { ConnectButton } from "@rainbow-me/rainbowkit";

export function NavBar() {
  const { data: session } = useSession();

  return (
    <nav>
      <Link href="/">Imvecto</Link>
      <Link href="/explore">Explore</Link>

      {session ? (
        <>
          <Link href="/dashboard">My activity</Link>
          <button onClick={() => signOut()}>Sign out</button>
        </>
      ) : (
        <Link href="/login">Sign in</Link>
      )}

      <ConnectButton />
    </nav>
  );
}
